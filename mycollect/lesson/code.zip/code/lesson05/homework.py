#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/11/30

# 找出两个列表中相同的元素
L1 = [1, 2, 3, 4]
L2 = [3, 4, 5, 6]
print(list(set(L1) & set(L2)))

# 新建一个字典，用3种方法往字典里面插入值；用 4 种方法取出value，用2种方法取出key
D = {
    "name": "fei",
    "age": 18
}
# 用3种方法往字典里面插入值
D.setdefault("height", 160)    # 有则查，无则增weight
print(D)
D["phone"] = 123456
print(D)
D.update({"address": "changsha"})
print(D)

# 用 4 种方法取出value
print(D["name"])
print(D.setdefault("name"))
print(D.get("name"))
print(list(D.values())[0])
print(list(D.items())[0][1])

# 用2种方法取出key


# 定义我们学过的每种数据类型，并且注明，哪些是可变，哪些是不可变的
# a.列表list:有序、可以修改，允许重复
# b.元组tuple:有序、不可以修改，允许重复
# c.字典dict:无序、可修改、键唯一，value可以重复
# d.集合set:无序、可修改、不允许重复
# 数字数据类型：不可以
# 字符串：不可以

