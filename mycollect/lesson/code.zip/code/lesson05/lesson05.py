#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/11/30

# 1.字符串的格式化：
# a.%d，%f，%s：必须一一对应，数据类型也要一致，否则报错
print("s")
s = "fei"
d = 18
print(s)
print("我叫%s，年龄%d。" % (s, d))

# b.format:python特有，不需要指定数据类型，不需要一一对应
print("我叫{}，年龄{}。".format(s, d))
print("我叫{0}，年龄{1}，真名{0}。".format(s, d))
L = ["fei", 18, "飞飞"]
print("我叫{}，年龄{}，真名{}。".format(*L))


# 2.回忆：encode、decode
# python3里面字符编码实际类型
# a.内存中字符运行的时候编码是unicode，用空间换时间
# b.硬盘存储中或者网络传输过程中用utf-8，追求空间

# 1字节==8位
# utf-8：英文：8；中文：24位
# unicode：所有的都是16位

# encode编码：unicode转换为指定编码
# decode解码：将原编码转换成unicode

s = "中"   # 程序执行时，“中”会以unicode形式存在在内存中

# encode编码
s1 = s.encode("utf-8")
print(s1)   # b'\xe4\xb8\xad' b ===>byte
s2 = s.encode("gbk")
print(s2)   # b'\xd6\xd0' b===>byte

# decode解码
print(s1.decode("utf-8"))
print(s2.decode("gbk"))

# gbk--->utf-8
print(s2.decode("gbk").encode("utf-8")) # b'\xe4\xb8\xad'

# 3.深浅拷贝
# id()
s = "飞"
n = 5
print(id(s))    # 3136762197536
print(id(n))    # 2009248960

# 字符串、数字：赋值还有深浅拷贝无意义的，因为其永远指向同一个内存地址
# 列表、元组、字典：赋值深浅拷贝
L = [1, 2, 3, 4]
print(id(L))
print(id(L[0]))
print(id(L[1]))

# 赋值
n1 = {"k1": "fei", "k2": 123, "k3": ["fly", 18]}
n2 = n1

print(id(n2))
print(id(n1))

# 浅拷贝
import copy
n1 = {"k1": "fei", "k2": 123, "k3": ["fly", 18]}
n3 = copy.copy(n1)  # 浅拷贝,只在内存中额外创建了第一层数据
print(id(n1))
print(id(n3))

print(id(n1["k3"]))
print(id(n3["k3"]))

# 深拷贝
n1 = {"k1": "fei", "k2": 123, "k3": ["fly", 18]}
n4 = copy.deepcopy(n1)
print(id(n1))
print(id(n4))

print(id(n1["k3"]))
print(id(n4["k3"]))

print(id(n1["k3"][0]))
print(id(n4["k3"][0]))

# 4.bytes和bytearray
# a.bytes
print(type("fei"))  # <class 'str'>
print(type(b"fei"))  # <class 'bytes'>

# 区别
# bytes是byte的序列，字符串是字符的序列
# str通过encode转换为bytes
s = "中"  # str
s1 = s.encode("utf-8")  # str通过encode转换为bytes
print(s1)   # b'\xe4\xb8\xad'

# bytes通过decode转换为str
s2 = s1.decode("utf-8")  # bytes通过decode转换为str
print(s2)   # str

# b.bytearray:可变
S1 = "你好，世界！"
print(S1.encode("utf-8"))   # bytes
B1 = bytearray(S1.encode("utf-8"))  # bytearray
print(B1)   # bytearray(b'\xe4\xbd\xa0\xe5\xa5\xbd\xef\xbc\x8c\xe4\xb8\x96\xe7\x95\x8c\xef\xbc\x81')
print(type(B1))  # <class 'bytearray'>

# 分解步骤
# S = "美丽"
# B2 = bytearray(S.encode("utf-8"))
# print(B2)
# B1[:6] = B2
#
# print(B1.decode("utf-8"))

# 整合
B1[:6] = bytearray("美丽", encoding="utf-8")
print(B1.decode("utf-8"))




