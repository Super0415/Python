#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/11/30

L = [1, 2, 3, 4]

D = {
    "name": "fei",
    "psw": "123456",
}


