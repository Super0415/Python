#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/11/27

L = ["a", "b", "c"]
# 正序0,1,2
# 反序-3，-2，-1
print(L[1:])
print(L[-2:])
print(L[::-2])
