#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/12/3

# 代码执行顺序
# 顺序执行
# 选择执行
# 循环执行
print("---1---")
print("---2---")
print("---3---")

# 选择执行：if
a = 5
if a > 3:
    print("a > 3")
"""
if 条件：
    条件满足，需要做的事情
"""

# if...else...
a = 5
if a < 3:
    print("a < 3")
else:
    print("a > 3")

"""
if 条件：
    条件满足，需要做的事情
else:
    条件不满足，需要做的事情    
"""

# 三目运算：if...else...简写
print("a < 3") if a < 3 else print("a > 3")

# 条件满足，需要做的事情 if 条件 else 条件不满足，需要做的事情

# if...elif...else...
a = 5
if a < 3:
    print("---1---")
elif 5 > a >= 3:
    print("---2---")
else:
    print("---3---")

"""
if 条件1：
    条件1满足，需要做的事情
elif 条件2：
     条件2满足，需要做的事情 
elif 条件3：
     条件3满足，需要做的事情  
     。。。
elif 条件n：
     条件n满足，需要做的事情          
else:
    条件均不满足，需要做的事情 
"""

# 注意：python里面是以缩进来实现代码块的（包含关系）
a = 5
if a < 3:
    print("---1---")
    print("---2---")
    print("---3---")
    print("---4---")
print("---5---")    # 打印输出

# 拓展
# a = input("请输入你的名字：")   # 输入,输入的是字符串
# print(a)

# a = int(input("请输入你的身高："))
# print(type(a))
# exit()
if a >= 170:
    print("你很高")
elif 159 < a < 170:
    print("身高刚刚好")
else:
    print("萝莉mm")

# while循环
# print("a < 3") if a < 3 else print("a > 3")

# 打印一到十的所有数字
i = 1
print(i)
i += 1  # i = i + 1
print(i)
i += 1
print(i)
# ....
i = 1
while i <= 10:
    print(i)
    i += 1
"""
while 条件：
    条件满足的时候，执行的事情
先判断，再执行    
"""

# 循环取值
li = [1, 3, 7, 5, 9]
print(li[0])    # 索引取值

i = 0
while li[i] < 5:
    print(li[i])
    i += 1

li = [1, 3, 7, 5, 9, 10, 12]
i = 0
while i < len(li):   # i < 10报错，超出了列表的序列,改为len（li）
    if li[i] > 20:
        print(li[i])
    else:
        print("小于20")
    i += 1  # 不加会死循环

# len（li）返回的是数字，列表的长度

# 循环+三目运算
li = [1, 3, 7, 5, 9, 10, 12]
i = 0
while i < len(li):
    # print(li[i]) if li[i] > 20 else print("小于20")
    print(True, end=" ") if li[i] > 20 else print(False, end=" ")
    i += 1

# while: 循环执行判断

print("=========================")
# 跳出循环break、continue
# li = [1, 3, 7, 5, 9, 10, 12]
# i = 0
# while i < len(li):
#     if li[i] == 5:
#         break
#     print(li[i])
#     i += 1
# print("---end---")

print("=========================")

# continue
# li = [1, 3, 7, 5, 9, 10, 12]
# i = -1
# while i < len(li):
#     i += 1
#     if li[i] == 5:
#         continue
#     print(li[i])
# print("---end---")

# 因为i值进入判断后，continue，回到while，而i值始终没有发生变化，所以再次判断就会重复以上。

# break跳出整个循环
# continue跳出当前循环，进入下一次循环

# li = [1, 2, 3, 4, 5, 6, 7]
# i = -1
# while i < len(li):
#     i += 1
#     if li[i] == 3:
#         continue
#     print(li[i])

print("==========================")
# else
L = [1, 3, 7, 5, 9]
n = 0
while n < len(L):
    n += 1
    if L[n] == 5:
        break
    print(L[n])
else:
    print("---end---")

# else可以跟在while后面，但是要注意，必须是循环自己终止的，才会执行，如果是break掉的是不执行的。











