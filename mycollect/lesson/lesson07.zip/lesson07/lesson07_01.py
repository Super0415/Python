#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/12/3

# for循环
# 列表的遍历
li = [1, 3, 7, 5, 9]
for i in li:
    print(i)

print("=========================")
# 元组的遍历
T = (1, 3, 7, 5, 9)
for i in T:
    print(i)
print("=========================")
# 字典
D = {"k1": "v1", "k2": "v2", "k3": "v3"}
for k, v in D.items():
    print(k, v)
print("=========================")
# 集合,无序
S = {"k1", "k2", "k3"}
for i in S:
    print(i)
print("=========================")

# for也有死循环，如下：
li = [1, 3, 7, 5, 9]
for i in li:
    # li.append(5)
    print(i)

# 注意：如果是可变对象，一定不要往循环里面去插入东西。

# 可迭代，怎么判断一个对象是否是可迭代对象
# 1.for循环，可迭代对象
# 2.对象里是否有iter方法
print("=========================")
print(dir(li))

# range():内置函数，表示的是一个范围
# 传一个参数，左闭右开
print("=========================")
for i in range(5):
    print(i)

print("=========================")
# 传两个参数
for i in range(1, 5):
    print(i)

print("=========================")
# 传三个参数
for i in range(1, 5, 2):
    print(i)

print(range(1, 5))
print(list(range(1, 5)))

print("=========================")
# continue/break/else
for i in range(1, 21):
    if i % 5 == 0:
        break
        # continue
    print(i)
else:
    print("-----end-----")

# for同while

# for i in range(1, 10):
#     for j in range(1, 10):
#         print(i, j)


