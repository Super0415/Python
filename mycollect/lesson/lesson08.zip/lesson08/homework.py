#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/12/4

# 1*1=1
# 1*2=2 2*2=4
# i * j = ?

# for i in range(1, 10):
#     for j in range(1, i + 1):
#         print("{}*{}={}".format(j, i, i*j), end=" ")
#     print()
for i in range(1, 10):
    for j in range(1, i+1):
        print(i, j)
# i = 1:j =1        i+1=2
# i = 2:j =1 ,2     i+1=3
# i = 3:j =1, 2, 3  i+1=4
# ....
# i = 9:j =1,2,3,4,5,6,7,8,9

