#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/12/4

# 函数。
# li = [1, 3, 5, 9, 8]
# for i in li:
#     print(True if i > 5 else False)

# 功能一

# 功能二

# 。。。。
# 功能n


# def func(li):
#     """
#     判断
#     :param li:
#     :return:
#     """
#     for i in li:
#         print(True if i > 5 else False)
#     return li
#
#
# li = [1, 3, 5, 9, 8]
# print(func(li))

# 函数标准格式
"""
def 函数名（参数。。。）：  
    '''
    函数接口
    '''  
    函数体
    return 返回值 
"""


# 函数定义和我们变量是一样
# 函数调用
def f1(x, y):
    print("我是{}{}".format(x, y))


f1(6, 7)

# 参数
# 形参：函数没有调用的时候，它没有任何意义，在调用时，必须传入参数，所以也叫必须参数
# 实参：与形参在位置是一一对应的，所以也叫位置参数。
# 缺一不可，缺了会报错，多了也会报错

# 默认参数:不传参，用默认值，传参它也能接收。


def f1(x, y=666):
    print("我是{}{}".format(x, y))


f1(6, 555)
# 默认参数，一定是放在必须参数后面，这是语法，否则会报错

# 关键字参数


def f1(x, y):
    print("我是{}{}".format(x, y))


f1(y=88, x=66)
# 通过关键字去找对应的必须参数，这样就不需要一一对应了

# 动态参数
# 一般写法：def f1(*args,**kwargs)
# *args:调用函数时，所有的传入的多余的位置参数，都会被args接收生成一个元组。


def sum(*args):
    result = 0
    for i in args:
        result += i
    print(result)


sum(1, 2)
sum(1, 5, 9)
sum(1, 8, 6666, 9999)

# **kwargs:函数调用时，多余的关键字参数，都会被kwargs接收，生成一个字典


def sum(**kwargs):
    # print(kwargs)
    print("b:", kwargs["b"])
    result = 0
    for i in kwargs.values():
        result += i
    print(result)


sum(a=1, b=2)
sum(a=1, b=5, c=9)
sum(c=1, a=8, b=6666, d=9999)

# 梳理
# a.第一种


def f1(*args):
    print(type(args))


f1(123, 456, 789)

# b. 第二种


def f2(**kwargs):
    print(type(kwargs))


f2(k1=123, k2=456, k3=789)

# c.混合使用


def f3(x, *args, **kwargs):
    print(type(x))
    print(type(args))
    print(type(kwargs))


f3(11, 22, 33, k1=123, k2=456)

# d.扩展，为动态参数传入列表、字典、元组
# 列表


def f1(*args):
    print(type(args))
    print(args)


li = [11, 22, 33]
f1(11, 22, 33)  # (11, 22, 33)
f1(li, 2233)    # ([11, 22, 33], 2233)
f1(*li)     # (11, 22, 33)

# 字典


def f2(**kwargs):
    print(type(kwargs))
    print(kwargs)


dic = {"k1": 123, "k2": 456}
f2(**dic)

# return


def sum(*args):
    result = 0
    for i in args:
        result += i

    # print(result)
    return result


b = sum(1, 2, 3)
s = b + 5
print(s)

