#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author:fei time:2018/12/4

# 常用内置函数：72
func_list = dir(__builtins__)
# print(func_list)
func_list = func_list[func_list.index("abs"):]

for i in range(len(func_list)):
    print('%s.%s()' % (i + 1, func_list[i]))

# 演示
li = [3, 1, 5]
print(len(li))
print(min(li))
print(max(li))
print(sorted(li))
print(sorted(li, reverse=True))
# 类名.方法（）
# 方法（）
print(list(reversed(li)))
print(sum(li))

# 几个可能用到的内置函数（补充）
# enumerate 返回一个可以遍历的对象
li = ["a", "b", "c"]
for i in enumerate(li):
    print(i)

print(list(enumerate(li)))
print(dict(enumerate(li)))

# eval():取出字符串的内容，当做表达式进行运算并有返回值
b = "1 + 2 + 3"
print(eval(b))

# exec():执行字符串，没有返回值
exec("a = 1")
# print(a)
S = """
z = 10
s = x + y + z
print(s)
print("ok")
"""
x = 1
y = 2
exec(S)

# filter(函数，可迭代对象):过滤器,每个可迭代对象去执行函数，获取满足条件，不满足的删去


def f1(x):
    return x > 10


L1 = [10, 2, 30, 50, 15]
print(list(filter(f1, L1)))  # [30, 50, 15]
print("f2:", list(map(f1, L1)))  # 区别：filter是对对象的筛选获取的是对象元素，map是获取的表达式的值

# map():对于可迭代参数，应用函数，结果返回


def f2(y):
    return y*10


L2 = [1, 3, 5]
print(list(map(f2, L2)))

# zip：配对
L3 = [1, 2, 3, 4]
L4 = ["a", "b", "c"]
b = zip(L3, L4)
print(b)
print(dict(b))  # {1: 'a', 2: 'b', 3: 'c'}
# print(list(b))  # [(1, 'a'), (2, 'b'), (3, 'c')]


